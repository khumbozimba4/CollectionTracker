<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SalesPersonController extends Controller
{
    //
}
