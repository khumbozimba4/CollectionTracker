<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="footer-inner-wraper">
      <div class="d-sm-flex justify-content-center justify-content-sm-between py-2">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="#" target="_blank">MTL Collections </a><script>document.write(new Date().getFullYear());</script> </span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Contact: <a href="mailto:victor.chisanga@mtl.mw">Victor Chisanga</a></span>
      </div>
    </div>
  </footer>
  <!-- partial -->
